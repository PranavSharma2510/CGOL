/*
 ============================================================================
 Name        : CGOL.c
 Author      : Pranav Sharma 
 Version     :
 Copyright   : Your copyright notice
 Description : Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include<stdio.h>

int rowSize, colSize, as, aliveRow, aliveCol, generations;              
void NextGeneration(int a[rowSize][colSize], int rowSize, int colSize);   

int main()
    {

	printf("Enter the size of row\n");
	scanf("%d", &rowSize);                
	printf("Enter the size of column\n");
	scanf("%d", &colSize);                

   int a[rowSize][colSize];

   for(int p = 0; p<rowSize; p++){
	   for(int q = 0; q<colSize; q++){
		   a[p][q] = 0;                    
	   }
   }

   printf("Enter the number of alive cells in the grid\n");
   scanf("%d", &as);        

   for(int o = 0; o<as; o++){               
	   printf("Enter the position of the alive cell in the row\n");
	   scanf("%d", &aliveRow);
	   printf("Enter the position of the alive cell in the column\n");
	   scanf("%d", &colSize);
	   a[aliveRow][aliveCol] = 1;    

   }
    
        printf("Initial State\n");    
        for (int i = 0; i < rowSize; i++)
        {
            for (int j = 0; j < colSize; j++)
            {
                if (a[i][j] == 0)
                    printf("0");        
                else
                    printf("1");    
            }
           printf("\n");
        }
       printf("\n");
        NextGeneration(a, rowSize, colSize);     
    }


    void NextGeneration(int a[rowSize][colSize], int rowSize, int colSize)       
                                                                                     
    {

        int no = 1;
    	int b[rowSize][colSize];                   

    printf("Enter the number of generations\n");
    scanf("%d", &generations);                        
    printf("\n");

    for(int g = 0; g<generations; g++){        
        for (int l = 1; l < rowSize ; l++)    
        {
            for (int m = 1; m < colSize ; m++) 
            {

            	 int numOfAliveNeighbours = 0;           


            if(l == 0){                     
            	for (int i = 0; i <= 1; i++)           
            	   for (int j = -1; j <= 1; j++)        
            	     numOfAliveNeighbours += a[l + i][m + j];   

           	         numOfAliveNeighbours -= a[l][m];       
            }


            else if(l == 0 && m == 0){  
            	for (int i = 0; i <= 1; i++)            
            	   for (int j = 0; j <= 1; j++)        
            	     numOfAliveNeighbours += a[l + i][m + j];   

            	     numOfAliveNeighbours -= a[l][m];       

            }


            else if(m == 0){                
            	for (int i = -1; i <= 1; i++)            
            	   for (int j = 0; j <= 1; j++)        
            	     numOfAliveNeighbours += a[l + i][m + j];   

            	     numOfAliveNeighbours -= a[l][m];       

            }


            else if(m == 0 && l == rowSize - 1){       
            	for (int i = -1; i < 1; i++)            
            	   for (int j = 0; j <= 1; j++)        
            	     numOfAliveNeighbours += a[l + i][m + j];   

            	     numOfAliveNeighbours -= a[l][m];      

            }

            else if(l == rowSize - 1){                 
            	for (int i = -1; i < 1; i++)            
            	   for (int j = -1; j <= 1; j++)        
            	     numOfAliveNeighbours += a[l + i][m + j];   

            	     numOfAliveNeighbours -= a[l][m];       

            }

            else if(l == rowSize -1 && m == colSize -1){     
            	for (int i = -1; i < 1; i++)           
            	   for (int j = -1; j < 1; j++)        
            	     numOfAliveNeighbours += a[l + i][m + j];  

            	     numOfAliveNeighbours -= a[l][m];       

            }

            else if(m == colSize -1 ){                  
            	for (int i = -1; i <= 1; i++)            
            	   for (int j = -1; j < 1; j++)        
            	     numOfAliveNeighbours += a[l + i][m + j];   

            	     numOfAliveNeighbours -= a[l][m];      

            }

            else if(l == 0 && m == colSize - 1){       
            	for (int i = 0; i <= 1; i++)            
            	   for (int j = -1; j < 1; j++)        
            	     numOfAliveNeighbours += a[l + i][m + j];   

            	     numOfAliveNeighbours -= a[l][m];      

            }

            else {
            	for (int i = -1; i <= 1; i++)            
            	   for (int j = -1; j <= 1; j++)        
            	     numOfAliveNeighbours += a[l + i][m + j];   

            	     numOfAliveNeighbours -= a[l][m];       

            }

    

            
                if ((a[l][m] == 1) && (numOfAliveNeighbours < 2))
                    b[l][m] = 0;

                
                else if ((a[l][m] == 1) && (numOfAliveNeighbours > 3))
                    b[l][m] = 0;

                
                else if ((a[l][m] == 0) && (numOfAliveNeighbours == 3))
                    b[l][m] = 1;

                
                else
                    b[l][m] = a[l][m];
            }
        }


        printf("%d Generation:\n", no);          
            no++;
        for (int i = 0; i < rowSize; i++)
        {
            for (int j = 0; j < colSize; j++)
            {
                if (a[i][j] == 0)
                   printf("0");        
                else
                    printf("1");       
            }
            printf("\n");
        }
        printf("\n");
    }
    }



